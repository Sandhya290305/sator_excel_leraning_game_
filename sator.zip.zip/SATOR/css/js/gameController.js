
console.log("Game Controller Loaded");
let currentLevelIndex = 0;
let score = 0;

function startGame() {
  currentLevelIndex = 0;
  score = 0;
  loadLevel();
}

function loadLevel() {
  const level = levels[currentLevelIndex];

  document.getElementById("instruction").innerText =
    level.instruction;

  speak(level.instruction); // your existing voice logic
}

function submitAnswer(userAnswer) {
  const level = levels[currentLevelIndex];

  if (validateAnswer(userAnswer, level)) {
    score += 10;
    currentLevelIndex++;

    if (currentLevelIndex < levels.length) {
      loadLevel();
    } else {
      endGame();
    }
  } else {
    alert("Try again");
  }
}

function endGame() {
  document.getElementById("instruction").innerText =
    "Game completed! Score: " + score;
}
