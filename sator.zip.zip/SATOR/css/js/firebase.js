

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAMGKJDVMAnFGdUYQbh5W6QdtgTvQNPkPQ",
  authDomain: "SATOR.firebaseapp.com",
  projectId: "sator-6b53a",
  storageBucket: "sator-6b53a.firebasestorage.app",
  messagingSenderId: "XXXX",
  appId: "1:722021431866:android:99c2c8fc68b28699e6d303"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
