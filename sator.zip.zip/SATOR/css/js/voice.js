function speak(text)
 {
  const msg = new SpeechSynthesisUtterance(text);
  msg.rate = 0.9;
  speechSynthesis.cancel();
  speechSynthesis.speak(msg);
}

let selectedVoice = null;

function initVoice() 
{
  const voices = window.speechSynthesis.getVoices();

  // Prefer professional English voice
  selectedVoice = voices.find(v =>
    v.lang.includes("en") &&
    (v.name.includes("Google") || v.name.includes("Microsoft"))
  ) || voices[0];
}

speechSynthesis.onvoiceschanged = initVoice;

function speak(text, options = {}) 
{
  if (!window.speechSynthesis) return;

  const utterance = new SpeechSynthesisUtterance(text);

  utterance.voice = selectedVoice;
  utterance.rate = options.rate || 0.95;
  utterance.pitch = options.pitch || 1;
  utterance.volume = options.volume || 1;

  window.speechSynthesis.cancel(); // stop previous voice
  window.speechSynthesis.speak(utterance);
}
speak(
  `Task ${currentTask.taskId}. ${currentTask.situation}`,
  { rate: 0.9 }
);
function announceLevel(level) {
  speak(
    `Welcome to Level ${level.level}. ${level.careerStage}. 
     Difficulty: ${level.difficulty}. 
     Focus area: ${level.theme}.`,
    { rate: 0.85 }
  );
}
announceLevel(currentLevelData);
speak("Correct. Well done. Proceeding to the next task.");
speak("That is not correct. Please review the situation and try again.");
speak("Time is up. The task has been reset.");
speak(
  `Congratulations. You have completed ${currentLevelData.careerStage}. 
   Promotion unlocked.`,
  { rate: 0.85 }
);

