import { db } from "../firebase/firebase.js";
import {
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

document.addEventListener("DOMContentLoaded", () => {
  const startBtn = document.getElementById("startBtn");
  const submitBtn = document.getElementById("submitBtn");

  if (startBtn) {
    startBtn.addEventListener("click", startGame);
  }

  if (submitBtn) {
    submitBtn.addEventListener("click", submitAnswer);
  }
});

let uploadExcelData=null;
let levelsData=[];
let currentLevel = 0;
let currentTask = 0;
let score = 0;
let playerName = "";

fetch("js/levels.json")
  .then(res => res.json())
  .then(data =>{
     levelsData = data.levels;
   console.log("Levels loaded", levelsData);
  });
window.startGame=function () {
  console.log("Start button clicked");
  const playerName = document.getElementById("username").value;
  if (!playerName) {
    alert("Enter name");
  return;}

  document.getElementById("userBox").classList.add("hidden");
  document.getElementById("gameArea").classList.remove("hidden");

  loadTask();
}

function loadTask() {
  const task = levelsData[currentLevel].tasks[currentTask];
  document.getElementById("levelTitle").innerText =
    `Level ${levelsData[currentLevel].level}`;
  document.getElementById("situation").innerText = task.situation;

  speak(task.situation);
}

function submitAnswer() {
  const input = document.getElementById("answerInput").value;
  const task = levelsData[currentLevel].tasks[currentTask];

document.getElementById("submitExcel").addEventListener("click", () => {
  const file = document.getElementById("excelUpload").files[0];
  if (!file) {
    alert("Upload Excel file first");
    return;
  }

  const reader = new FileReader();
  reader.onload = e => {
    const workbook = XLSX.read(e.target.result, { type: "binary" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    uploadedExcelData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

    runCurrentTask();
  };

  reader.readAsBinaryString(file);
});

function runCurrentTask() {
  const task = levelsData[0].tasks[0];

  const result = validateExcelTask(task, uploadedExcelData);

  if (result.success) {
    score += result.points;
    alert(`✅ Correct! Result: ${result.calculatedResult}`);
  } else {
    alert(`❌ ${result.message}`);
  }
}

  if (validate(input, task)) {
    document.getElementById("correctSound").play();
    score += task.points;
    currentTask++;
    document.getElementById("score").innerText = score;

    if (currentTask >= levelsData[currentLevel].tasks.length) {
      document.getElementById("levelUpSound").play();
      currentLevel++;
      currentTask = 0;
    }

    loadTask(renderInput(level));
  } else {
    document.getElementById("wrongSound").play();
    alert("Try again");
  }
}
function renderInput(level)
 {
  if (level.type === "excel") {
    formulaInput.style.display = "block";
    formulaInput.placeholder = "=FORMULA()";
  } else {
    formulaInput.style.display = "block";
    formulaInput.placeholder = "Type answer (e.g., Animations)";
  }
}

