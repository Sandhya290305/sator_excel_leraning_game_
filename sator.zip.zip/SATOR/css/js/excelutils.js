function columnLetterToIndex(letter) {
  let index = 0;
  for (let i = 0; i < letter.length; i++) {
    index = index * 26 + (letter.charCodeAt(i) - 64);
  }
  return index - 1;
}

function extractRange(excelData, range) {
  const [start, end] = range.split(":");

  const startCol = start.match(/[A-Z]+/)[0];
  const startRow = parseInt(start.match(/\d+/)[0], 10) - 1;

  const endCol = end.match(/[A-Z]+/)[0];
  const endRow = parseInt(end.match(/\d+/)[0], 10) - 1;

  const colIndex = columnLetterToIndex(startCol);
  const values = [];

  for (let row = startRow; row <= endRow; row++) {
    const cellValue = excelData[row]?.[colIndex];
    if (typeof cellValue === "number") {
      values.push(cellValue);
    }
  }

  return values;
}
