function validateAnswer(userAnswer, level)
 {
  if (task.validationType === "formula")
     {
    return userInput.replace(/\s/g,"").toUpperCase() ===
           task.expectedAnswer.replace(/\s/g,"").toUpperCase();
  }
  return userAnswer===level.answer;
  return userInput.toLowerCase()
    .includes(task.expectedAnswer.toLowerCase());
}
