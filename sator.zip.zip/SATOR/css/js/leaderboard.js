import { db } from "../firebase/firebaseConfig.js";
import {
  collection,
  query,
  orderBy,
  limit,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

const leaderboardList = document.getElementById("leaderboardList");

const q = query(
  collection(db, "leaderboard"),
  orderBy("score", "desc"),
  limit(10)
);

onSnapshot(q, (snapshot) => {
  leaderboardList.innerHTML = "";

  snapshot.forEach(doc => {
    const data = doc.data();
    const li = document.createElement("li");
    li.innerText = `${data.name} — ${data.score} pts`;
    leaderboardList.appendChild(li);
  });
});
