function validateExcelTask(task, excelData) {
  const values = extractRange(excelData, task.range);

  if (!values.length) {
    return { success: false, message: "No valid data found" };
  }

  let result;

  switch (task.operation) {
    case "SUM":
      result = values.reduce((a, b) => a + b, 0);
      break;

    case "AVERAGE":
      result = values.reduce((a, b) => a + b, 0) / values.length;
      break;

    case "MAX":
      result = Math.max(...values);
      break;

    case "MIN":
      result = Math.min(...values);
      break;

    case "COUNT":
      result = values.length;
      break;

    default:
      return { success: false, message: "Unsupported operation" };
  }

  return {
    success: true,
    calculatedResult: result,
    points: task.points
  };
}
