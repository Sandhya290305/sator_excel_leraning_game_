const correctSound = document.getElementById("correctSound");
const wrongSound = document.getElementById("wrongSound");
const levelUpSound = document.getElementById("levelUpSound");

function playCorrect() {
  correctSound.play();
}

function playWrong() {
  wrongSound.play();
}

function playLevelUp() {
  levelUpSound.play();
}
